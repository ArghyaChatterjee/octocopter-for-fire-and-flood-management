using System;
using System.Collections.Generic;
using System.Text;

namespace KMLib
{
    public class LookAt
    {
        public double longitude;
        public double latitude;
        public double range;
        public double tilt;
        public double heading;
    }
}
