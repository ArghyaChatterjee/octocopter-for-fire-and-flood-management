﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MissionPlanner.GeoRef
{
    public class VehicleLocation : SingleLocation
    {
    }
}