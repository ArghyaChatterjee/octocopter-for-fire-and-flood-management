﻿namespace MissionPlanner
{
    public enum speeds
    {
        meters_per_second,
        fps,
        kph,
        mph,
        knots
    }
}