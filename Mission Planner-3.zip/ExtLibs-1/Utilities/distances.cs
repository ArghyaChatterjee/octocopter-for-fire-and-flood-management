﻿namespace MissionPlanner
{
    public enum distances
    {
        Meters,
        Feet
    }
}