﻿namespace MissionPlanner
{
    public enum altitudes
    {
        Meters,
        Feet
    }
}