﻿
to use saved settings
set
CommsBase.SettingsOption