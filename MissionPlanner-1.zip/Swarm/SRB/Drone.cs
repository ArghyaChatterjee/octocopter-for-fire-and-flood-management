﻿namespace MissionPlanner.Swarm.SRB
{
    public class Drone : DroneBase
    {
        public bool takeoffdone;
    }
}