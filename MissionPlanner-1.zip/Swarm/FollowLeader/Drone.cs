﻿namespace MissionPlanner.Swarm.FollowLeader
{
    public class Drone : DroneBase
    {
    }
}
