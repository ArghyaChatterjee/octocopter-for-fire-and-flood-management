﻿namespace MissionPlanner.Swarm.WaypointLeader
{
    public class Drone : DroneBase
    {
        public int PathIndex = 0;

        public bool takeoffdone = false;
    }
}
