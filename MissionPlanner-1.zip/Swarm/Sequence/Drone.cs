﻿namespace MissionPlanner.Swarm.Sequence
{
    public class Drone : DroneBase
    {

    }
}