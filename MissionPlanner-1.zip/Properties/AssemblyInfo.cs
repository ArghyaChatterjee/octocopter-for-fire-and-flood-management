﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Mission Planner")]
[assembly: AssemblyDescription("Mission Planner ground control station for ardupilot")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Michael Oborne")]
[assembly: AssemblyProduct("Mission Planner")]
[assembly: AssemblyCopyright("Copyright ©  2010-2019")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("30df5f32-c0e4-44f9-a284-a82d20821bda")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.3.*")]
[assembly: AssemblyFileVersion("1.3.68.1")]
