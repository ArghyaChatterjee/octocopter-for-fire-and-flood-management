﻿#!/bin/sh
mono MissionPlanner.exe