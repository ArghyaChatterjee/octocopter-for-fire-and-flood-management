﻿namespace MissionPlanner
{
    partial class temp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(temp));
            this.but_osdvideo = new MissionPlanner.Controls.MyButton();
            this.BUT_outputMD = new MissionPlanner.Controls.MyButton();
            this.BUT_paramgen = new MissionPlanner.Controls.MyButton();
            this.BUT_follow_me = new MissionPlanner.Controls.MyButton();
            this.BUT_georefimage = new MissionPlanner.Controls.MyButton();
            this.BUT_lang_edit = new MissionPlanner.Controls.MyButton();
            this.BUT_clearcustommaps = new MissionPlanner.Controls.MyButton();
            this.BUT_geinjection = new MissionPlanner.Controls.MyButton();
            this.BUT_swarm = new MissionPlanner.Controls.MyButton();
            this.BUT_outputnmea = new MissionPlanner.Controls.MyButton();
            this.BUT_outputMavlink = new MissionPlanner.Controls.MyButton();
            this.BUT_followleader = new MissionPlanner.Controls.MyButton();
            this.BUT_sorttlogs = new MissionPlanner.Controls.MyButton();
            this.BUT_movingbase = new MissionPlanner.Controls.MyButton();
            this.but_getfw = new MissionPlanner.Controls.MyButton();
            this.but_mavserialport = new MissionPlanner.Controls.MyButton();
            this.button3 = new MissionPlanner.Controls.MyButton();
            this.BUT_shptopoly = new MissionPlanner.Controls.MyButton();
            this.but_gimbaltest = new MissionPlanner.Controls.MyButton();
            this.but_maplogs = new MissionPlanner.Controls.MyButton();
            this.butlogindex = new MissionPlanner.Controls.MyButton();
            this.but_structtest = new MissionPlanner.Controls.MyButton();
            this.but_armandtakeoff = new MissionPlanner.Controls.MyButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label12 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.but_anonlog = new MissionPlanner.Controls.MyButton();
            this.but_dashware = new MissionPlanner.Controls.MyButton();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.but_sitl_comb = new MissionPlanner.Controls.MyButton();
            this.but_injectgps = new MissionPlanner.Controls.MyButton();
            this.BUT_fft = new MissionPlanner.Controls.MyButton();
            this.but_reboot = new MissionPlanner.Controls.MyButton();
            this.BUT_QNH = new MissionPlanner.Controls.MyButton();
            this.but_trimble = new MissionPlanner.Controls.MyButton();
            this.myButton_vlc = new MissionPlanner.Controls.MyButton();
            this.but_gstream = new MissionPlanner.Controls.MyButton();
            this.but_agemapdata = new MissionPlanner.Controls.MyButton();
            this.myButton1 = new MissionPlanner.Controls.MyButton();
            this.but_signkey = new MissionPlanner.Controls.MyButton();
            this.but_optflowcalib = new MissionPlanner.Controls.MyButton();
            this.myButton2 = new MissionPlanner.Controls.MyButton();
            this.BUT_magfit2 = new MissionPlanner.Controls.MyButton();
            this.but_gpsinj = new MissionPlanner.Controls.MyButton();
         
            this.but_followswarm = new MissionPlanner.Controls.MyButton();
            this.myButton3 = new MissionPlanner.Controls.MyButton();
            this.but_GDAL = new MissionPlanner.Controls.MyButton();
            this.but_sortlogs = new MissionPlanner.Controls.MyButton();
            this.but_logdlscp = new MissionPlanner.Controls.MyButton();
            this.but_td = new MissionPlanner.Controls.MyButton();
            this.but_dem = new MissionPlanner.Controls.MyButton();
            this.but_proximity = new MissionPlanner.Controls.MyButton();
            this.but_mavinspector = new MissionPlanner.Controls.MyButton();
            this.but_blupdate = new MissionPlanner.Controls.MyButton();
            this.but_3dmap = new MissionPlanner.Controls.MyButton();
            this.but_messageinterval = new MissionPlanner.Controls.MyButton();
            this.but_disablearmswitch = new MissionPlanner.Controls.MyButton();
            this.but_hwids = new MissionPlanner.Controls.MyButton();
            this.but_packetbytes = new MissionPlanner.Controls.MyButton();
            this.but_acbarohight = new MissionPlanner.Controls.MyButton();
            this.but_stayoutest = new MissionPlanner.Controls.MyButton();
            this.but_driverclean = new MissionPlanner.Controls.MyButton();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // but_osdvideo
            // 
            resources.ApplyResources(this.but_osdvideo, "but_osdvideo");
            this.but_osdvideo.Name = "but_osdvideo";
            this.but_osdvideo.UseVisualStyleBackColor = true;
            this.but_osdvideo.Click += new System.EventHandler(this.but_osdvideo_Click);
            // 
            // BUT_outputMD
            // 
            resources.ApplyResources(this.BUT_outputMD, "BUT_outputMD");
            this.BUT_outputMD.Name = "BUT_outputMD";
            this.BUT_outputMD.UseVisualStyleBackColor = true;
            this.BUT_outputMD.Click += new System.EventHandler(this.myButton1_Click);
            // 
            // BUT_paramgen
            // 
            resources.ApplyResources(this.BUT_paramgen, "BUT_paramgen");
            this.BUT_paramgen.Name = "BUT_paramgen";
            this.BUT_paramgen.UseVisualStyleBackColor = true;
            this.BUT_paramgen.Click += new System.EventHandler(this.BUT_paramgen_Click);
            // 
            // BUT_follow_me
            // 
            resources.ApplyResources(this.BUT_follow_me, "BUT_follow_me");
            this.BUT_follow_me.Name = "BUT_follow_me";
            this.BUT_follow_me.UseVisualStyleBackColor = true;
            this.BUT_follow_me.Click += new System.EventHandler(this.BUT_follow_me_Click);
            // 
            // BUT_georefimage
            // 
            resources.ApplyResources(this.BUT_georefimage, "BUT_georefimage");
            this.BUT_georefimage.Name = "BUT_georefimage";
            this.BUT_georefimage.Click += new System.EventHandler(this.BUT_georefimage_Click);
            // 
            // BUT_lang_edit
            // 
            resources.ApplyResources(this.BUT_lang_edit, "BUT_lang_edit");
            this.BUT_lang_edit.Name = "BUT_lang_edit";
            this.BUT_lang_edit.UseVisualStyleBackColor = true;
            this.BUT_lang_edit.Click += new System.EventHandler(this.BUT_lang_edit_Click);
            // 
            // BUT_clearcustommaps
            // 
            resources.ApplyResources(this.BUT_clearcustommaps, "BUT_clearcustommaps");
            this.BUT_clearcustommaps.Name = "BUT_clearcustommaps";
            this.BUT_clearcustommaps.UseVisualStyleBackColor = true;
            this.BUT_clearcustommaps.Click += new System.EventHandler(this.BUT_clearcustommaps_Click);
            // 
            // BUT_geinjection
            // 
            resources.ApplyResources(this.BUT_geinjection, "BUT_geinjection");
            this.BUT_geinjection.Name = "BUT_geinjection";
            this.BUT_geinjection.UseVisualStyleBackColor = true;
            this.BUT_geinjection.Click += new System.EventHandler(this.BUT_geinjection_Click);
            // 
            // BUT_swarm
            // 
            resources.ApplyResources(this.BUT_swarm, "BUT_swarm");
            this.BUT_swarm.Name = "BUT_swarm";
            this.BUT_swarm.UseVisualStyleBackColor = true;
            this.BUT_swarm.Click += new System.EventHandler(this.BUT_swarm_Click);
            // 
            // BUT_outputnmea
            // 
            resources.ApplyResources(this.BUT_outputnmea, "BUT_outputnmea");
            this.BUT_outputnmea.Name = "BUT_outputnmea";
            this.BUT_outputnmea.UseVisualStyleBackColor = true;
            this.BUT_outputnmea.Click += new System.EventHandler(this.BUT_outputnmea_Click);
            // 
            // BUT_outputMavlink
            // 
            resources.ApplyResources(this.BUT_outputMavlink, "BUT_outputMavlink");
            this.BUT_outputMavlink.Name = "BUT_outputMavlink";
            this.BUT_outputMavlink.UseVisualStyleBackColor = true;
            this.BUT_outputMavlink.Click += new System.EventHandler(this.BUT_outputMavlink_Click);
            // 
            // BUT_followleader
            // 
            resources.ApplyResources(this.BUT_followleader, "BUT_followleader");
            this.BUT_followleader.Name = "BUT_followleader";
            this.BUT_followleader.UseVisualStyleBackColor = true;
            this.BUT_followleader.Click += new System.EventHandler(this.BUT_followleader_Click);
            // 
            // BUT_sorttlogs
            // 
            resources.ApplyResources(this.BUT_sorttlogs, "BUT_sorttlogs");
            this.BUT_sorttlogs.Name = "BUT_sorttlogs";
            this.BUT_sorttlogs.UseVisualStyleBackColor = true;
            this.BUT_sorttlogs.Click += new System.EventHandler(this.BUT_sorttlogs_Click);
            // 
            // BUT_movingbase
            // 
            resources.ApplyResources(this.BUT_movingbase, "BUT_movingbase");
            this.BUT_movingbase.Name = "BUT_movingbase";
            this.BUT_movingbase.UseVisualStyleBackColor = true;
            this.BUT_movingbase.Click += new System.EventHandler(this.BUT_movingbase_Click);
            // 
            // but_getfw
            // 
            resources.ApplyResources(this.but_getfw, "but_getfw");
            this.but_getfw.Name = "but_getfw";
            this.but_getfw.UseVisualStyleBackColor = true;
            this.but_getfw.Click += new System.EventHandler(this.but_getfw_Click);
            // 
            // but_mavserialport
            // 
            resources.ApplyResources(this.but_mavserialport, "but_mavserialport");
            this.but_mavserialport.Name = "but_mavserialport";
            this.but_mavserialport.UseVisualStyleBackColor = true;
            this.but_mavserialport.Click += new System.EventHandler(this.but_mavserialport_Click);
            // 
            // button3
            // 
            resources.ApplyResources(this.button3, "button3");
            this.button3.Name = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // BUT_shptopoly
            // 
            resources.ApplyResources(this.BUT_shptopoly, "BUT_shptopoly");
            this.BUT_shptopoly.Name = "BUT_shptopoly";
            this.BUT_shptopoly.UseVisualStyleBackColor = true;
            this.BUT_shptopoly.Click += new System.EventHandler(this.BUT_shptopoly_Click);
            // 
            // but_gimbaltest
            // 
            resources.ApplyResources(this.but_gimbaltest, "but_gimbaltest");
            this.but_gimbaltest.Name = "but_gimbaltest";
            this.but_gimbaltest.UseVisualStyleBackColor = true;
            this.but_gimbaltest.Click += new System.EventHandler(this.but_gimbaltest_Click);
            // 
            // but_maplogs
            // 
            resources.ApplyResources(this.but_maplogs, "but_maplogs");
            this.but_maplogs.Name = "but_maplogs";
            this.but_maplogs.UseVisualStyleBackColor = true;
            this.but_maplogs.Click += new System.EventHandler(this.but_maplogs_Click);
            // 
            // butlogindex
            // 
            resources.ApplyResources(this.butlogindex, "butlogindex");
            this.butlogindex.Name = "butlogindex";
            this.butlogindex.UseVisualStyleBackColor = true;
            this.butlogindex.Click += new System.EventHandler(this.butlogindex_Click);
            // 
            // but_structtest
            // 
            resources.ApplyResources(this.but_structtest, "but_structtest");
            this.but_structtest.Name = "but_structtest";
            this.but_structtest.UseVisualStyleBackColor = true;
            this.but_structtest.Click += new System.EventHandler(this.but_structtest_Click);
            // 
            // but_armandtakeoff
            // 
            resources.ApplyResources(this.but_armandtakeoff, "but_armandtakeoff");
            this.but_armandtakeoff.Name = "but_armandtakeoff";
            this.but_armandtakeoff.Click += new System.EventHandler(this.but_armandtakeoff_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            resources.ApplyResources(this.tableLayoutPanel1, "tableLayoutPanel1");
            this.tableLayoutPanel1.Controls.Add(this.label12, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.label22, 1, 21);
            this.tableLayoutPanel1.Controls.Add(this.but_anonlog, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.but_dashware, 0, 21);
            this.tableLayoutPanel1.Controls.Add(this.label26, 1, 25);
            this.tableLayoutPanel1.Controls.Add(this.label25, 1, 24);
            this.tableLayoutPanel1.Controls.Add(this.label24, 1, 23);
            this.tableLayoutPanel1.Controls.Add(this.label23, 1, 22);
            this.tableLayoutPanel1.Controls.Add(this.label21, 1, 20);
            this.tableLayoutPanel1.Controls.Add(this.label20, 1, 19);
            this.tableLayoutPanel1.Controls.Add(this.label19, 1, 18);
            this.tableLayoutPanel1.Controls.Add(this.label18, 1, 17);
            this.tableLayoutPanel1.Controls.Add(this.butlogindex, 0, 25);
            this.tableLayoutPanel1.Controls.Add(this.but_armandtakeoff, 0, 22);
            this.tableLayoutPanel1.Controls.Add(this.but_maplogs, 0, 24);
            this.tableLayoutPanel1.Controls.Add(this.label17, 1, 16);
            this.tableLayoutPanel1.Controls.Add(this.but_gimbaltest, 0, 23);
            this.tableLayoutPanel1.Controls.Add(this.but_structtest, 0, 20);
            this.tableLayoutPanel1.Controls.Add(this.label15, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.label14, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.label13, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.label11, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.label10, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.label9, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.BUT_clearcustommaps, 0, 19);
            this.tableLayoutPanel1.Controls.Add(this.but_getfw, 0, 17);
            this.tableLayoutPanel1.Controls.Add(this.BUT_geinjection, 0, 18);
            this.tableLayoutPanel1.Controls.Add(this.label8, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label7, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.BUT_sorttlogs, 0, 16);
            this.tableLayoutPanel1.Controls.Add(this.label6, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label5, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label4, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.BUT_outputMavlink, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.BUT_outputMD, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.BUT_outputnmea, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.BUT_georefimage, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.button3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.BUT_lang_edit, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.BUT_follow_me, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.BUT_paramgen, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.but_osdvideo, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.BUT_movingbase, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.BUT_shptopoly, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.BUT_swarm, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.BUT_followleader, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.but_mavserialport, 0, 14);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.Name = "label22";
            // 
            // but_anonlog
            // 
            resources.ApplyResources(this.but_anonlog, "but_anonlog");
            this.but_anonlog.Name = "but_anonlog";
            this.but_anonlog.UseVisualStyleBackColor = true;
            this.but_anonlog.Click += new System.EventHandler(this.but_anonlog_Click);
            // 
            // but_dashware
            // 
            resources.ApplyResources(this.but_dashware, "but_dashware");
            this.but_dashware.Name = "but_dashware";
            this.but_dashware.UseVisualStyleBackColor = true;
            this.but_dashware.Click += new System.EventHandler(this.but_dashware_Click);
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.Name = "label26";
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.Name = "label25";
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.Name = "label24";
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.Name = "label23";
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.Name = "label21";
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.Name = "label20";
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.Name = "label19";
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.Name = "label18";
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.Name = "label17";
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.Name = "label15";
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // but_sitl_comb
            // 
            resources.ApplyResources(this.but_sitl_comb, "but_sitl_comb");
            this.but_sitl_comb.Name = "but_sitl_comb";
            this.but_sitl_comb.UseVisualStyleBackColor = true;
            this.but_sitl_comb.Click += new System.EventHandler(this.but_sitl_comb_Click);
            // 
            // but_injectgps
            // 
            resources.ApplyResources(this.but_injectgps, "but_injectgps");
            this.but_injectgps.Name = "but_injectgps";
            this.but_injectgps.UseVisualStyleBackColor = true;
            this.but_injectgps.Click += new System.EventHandler(this.but_injectgps_Click);
            // 
            // BUT_fft
            // 
            resources.ApplyResources(this.BUT_fft, "BUT_fft");
            this.BUT_fft.Name = "BUT_fft";
            this.BUT_fft.UseVisualStyleBackColor = true;
            this.BUT_fft.Click += new System.EventHandler(this.BUT_fft_Click);
            // 
            // but_reboot
            // 
            resources.ApplyResources(this.but_reboot, "but_reboot");
            this.but_reboot.Name = "but_reboot";
            this.but_reboot.UseVisualStyleBackColor = true;
            this.but_reboot.Click += new System.EventHandler(this.but_reboot_Click);
            // 
            // BUT_QNH
            // 
            resources.ApplyResources(this.BUT_QNH, "BUT_QNH");
            this.BUT_QNH.Name = "BUT_QNH";
            this.BUT_QNH.UseVisualStyleBackColor = true;
            this.BUT_QNH.Click += new System.EventHandler(this.BUT_QNH_Click);
            // 
            // but_trimble
            // 
            resources.ApplyResources(this.but_trimble, "but_trimble");
            this.but_trimble.Name = "but_trimble";
            this.but_trimble.UseVisualStyleBackColor = true;
            this.but_trimble.Click += new System.EventHandler(this.but_trimble_Click);
            // 
            // myButton_vlc
            // 
            resources.ApplyResources(this.myButton_vlc, "myButton_vlc");
            this.myButton_vlc.Name = "myButton_vlc";
            this.myButton_vlc.UseVisualStyleBackColor = true;
            this.myButton_vlc.Click += new System.EventHandler(this.myButton_vlc_Click);
            // 
            // but_gstream
            // 
            resources.ApplyResources(this.but_gstream, "but_gstream");
            this.but_gstream.Name = "but_gstream";
            this.but_gstream.UseVisualStyleBackColor = true;
            this.but_gstream.Click += new System.EventHandler(this.but_gstream_Click);
            // 
            // but_agemapdata
            // 
            resources.ApplyResources(this.but_agemapdata, "but_agemapdata");
            this.but_agemapdata.Name = "but_agemapdata";
            this.but_agemapdata.UseVisualStyleBackColor = true;
            this.but_agemapdata.Click += new System.EventHandler(this.but_agemapdata_Click);
            // 
            // myButton1
            // 
            resources.ApplyResources(this.myButton1, "myButton1");
            this.myButton1.Name = "myButton1";
            this.myButton1.UseVisualStyleBackColor = true;
            this.myButton1.Click += new System.EventHandler(this.myButton1_Click_2);
            // 
            // but_signkey
            // 
            resources.ApplyResources(this.but_signkey, "but_signkey");
            this.but_signkey.Name = "but_signkey";
            this.but_signkey.UseVisualStyleBackColor = true;
            this.but_signkey.Click += new System.EventHandler(this.but_signkey_Click);
            // 
            // but_optflowcalib
            // 
            resources.ApplyResources(this.but_optflowcalib, "but_optflowcalib");
            this.but_optflowcalib.Name = "but_optflowcalib";
            this.but_optflowcalib.UseVisualStyleBackColor = true;
            this.but_optflowcalib.Click += new System.EventHandler(this.but_optflowcalib_Click);
            // 
            // myButton2
            // 
            resources.ApplyResources(this.myButton2, "myButton2");
            this.myButton2.Name = "myButton2";
            this.myButton2.UseVisualStyleBackColor = true;
            this.myButton2.Click += new System.EventHandler(this.myButton2_Click);
            // 
            // BUT_magfit2
            // 
            resources.ApplyResources(this.BUT_magfit2, "BUT_magfit2");
            this.BUT_magfit2.Name = "BUT_magfit2";
            this.BUT_magfit2.UseVisualStyleBackColor = true;
            this.BUT_magfit2.Click += new System.EventHandler(this.BUT_magfit2_Click);
            // 
            // but_gpsinj
            // 
            resources.ApplyResources(this.but_gpsinj, "but_gpsinj");
            this.but_gpsinj.Name = "but_gpsinj";
            this.but_gpsinj.UseVisualStyleBackColor = true;
            this.but_gpsinj.Click += new System.EventHandler(this.but_gpsinj_Click);
            // 
            // controlSensorsStatus1
            // 
 
            // 
            // but_followswarm
            // 
            resources.ApplyResources(this.but_followswarm, "but_followswarm");
            this.but_followswarm.Name = "but_followswarm";
            this.but_followswarm.UseVisualStyleBackColor = true;
            this.but_followswarm.Click += new System.EventHandler(this.but_followswarm_Click);
            // 
            // myButton3
            // 
            resources.ApplyResources(this.myButton3, "myButton3");
            this.myButton3.Name = "myButton3";
            this.myButton3.UseVisualStyleBackColor = true;
            this.myButton3.Click += new System.EventHandler(this.myButton3_Click);
            // 
            // but_GDAL
            // 
            resources.ApplyResources(this.but_GDAL, "but_GDAL");
            this.but_GDAL.Name = "but_GDAL";
            this.but_GDAL.UseVisualStyleBackColor = true;
            this.but_GDAL.Click += new System.EventHandler(this.but_GDAL_Click);
            // 
            // but_sortlogs
            // 
            resources.ApplyResources(this.but_sortlogs, "but_sortlogs");
            this.but_sortlogs.Name = "but_sortlogs";
            this.but_sortlogs.UseVisualStyleBackColor = true;
            this.but_sortlogs.Click += new System.EventHandler(this.but_sortlogs_Click);
            // 
            // but_logdlscp
            // 
            resources.ApplyResources(this.but_logdlscp, "but_logdlscp");
            this.but_logdlscp.Name = "but_logdlscp";
            this.but_logdlscp.UseVisualStyleBackColor = true;
            this.but_logdlscp.Click += new System.EventHandler(this.but_logdlscp_Click);
            // 
            // but_td
            // 
            resources.ApplyResources(this.but_td, "but_td");
            this.but_td.Name = "but_td";
            this.but_td.UseVisualStyleBackColor = true;
            this.but_td.Click += new System.EventHandler(this.but_td_Click);
            // 
            // but_dem
            // 
            resources.ApplyResources(this.but_dem, "but_dem");
            this.but_dem.Name = "but_dem";
            this.but_dem.UseVisualStyleBackColor = true;
            this.but_dem.Click += new System.EventHandler(this.but_dem_Click);
            // 
            // but_proximity
            // 
            resources.ApplyResources(this.but_proximity, "but_proximity");
            this.but_proximity.Name = "but_proximity";
            this.but_proximity.UseVisualStyleBackColor = true;
            this.but_proximity.Click += new System.EventHandler(this.but_proximity_Click);
            // 
            // but_mavinspector
            // 
            resources.ApplyResources(this.but_mavinspector, "but_mavinspector");
            this.but_mavinspector.Name = "but_mavinspector";
            this.but_mavinspector.UseVisualStyleBackColor = true;
            this.but_mavinspector.Click += new System.EventHandler(this.but_mavinspector_Click);
            // 
            // but_blupdate
            // 
            resources.ApplyResources(this.but_blupdate, "but_blupdate");
            this.but_blupdate.Name = "but_blupdate";
            this.but_blupdate.UseVisualStyleBackColor = true;
            this.but_blupdate.Click += new System.EventHandler(this.but_blupdate_Click);
            // 
            // but_3dmap
            // 
            resources.ApplyResources(this.but_3dmap, "but_3dmap");
            this.but_3dmap.Name = "but_3dmap";
            this.but_3dmap.UseVisualStyleBackColor = true;
            this.but_3dmap.Click += new System.EventHandler(this.but_3dmap_Click);
            // 
            // but_messageinterval
            // 
            resources.ApplyResources(this.but_messageinterval, "but_messageinterval");
            this.but_messageinterval.Name = "but_messageinterval";
            this.but_messageinterval.UseVisualStyleBackColor = true;
            this.but_messageinterval.Click += new System.EventHandler(this.but_messageinterval_Click);
            // 
            // but_disablearmswitch
            // 
            resources.ApplyResources(this.but_disablearmswitch, "but_disablearmswitch");
            this.but_disablearmswitch.Name = "but_disablearmswitch";
            this.but_disablearmswitch.UseVisualStyleBackColor = true;
            this.but_disablearmswitch.Click += new System.EventHandler(this.but_disablearmswitch_Click);
            // 
            // but_hwids
            // 
            resources.ApplyResources(this.but_hwids, "but_hwids");
            this.but_hwids.Name = "but_hwids";
            this.but_hwids.UseVisualStyleBackColor = true;
            this.but_hwids.Click += new System.EventHandler(this.but_hwids_Click);
            // 
            // but_packetbytes
            // 
            resources.ApplyResources(this.but_packetbytes, "but_packetbytes");
            this.but_packetbytes.Name = "but_packetbytes";
            this.but_packetbytes.UseVisualStyleBackColor = true;
            this.but_packetbytes.Click += new System.EventHandler(this.but_packetbytes_Click);
            // 
            // but_acbarohight
            // 
            resources.ApplyResources(this.but_acbarohight, "but_acbarohight");
            this.but_acbarohight.Name = "but_acbarohight";
            this.but_acbarohight.UseVisualStyleBackColor = true;
            this.but_acbarohight.Click += new System.EventHandler(this.but_acbarohight_Click);
            // 
            // but_stayoutest
            // 
            resources.ApplyResources(this.but_stayoutest, "but_stayoutest");
            this.but_stayoutest.Name = "but_stayoutest";
            this.but_stayoutest.UseVisualStyleBackColor = true;
            this.but_stayoutest.Click += new System.EventHandler(this.But_stayoutest_Click);
            // 
            // but_driverclean
            // 
            resources.ApplyResources(this.but_driverclean, "but_driverclean");
            this.but_driverclean.Name = "but_driverclean";
            this.but_driverclean.UseVisualStyleBackColor = true;
            this.but_driverclean.Click += new System.EventHandler(this.BUT_driverclean_Click);
            // 
            // temp
            // 
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.but_driverclean);
            this.Controls.Add(this.but_stayoutest);
            this.Controls.Add(this.but_acbarohight);
            this.Controls.Add(this.but_packetbytes);
            this.Controls.Add(this.but_hwids);
            this.Controls.Add(this.but_disablearmswitch);
            this.Controls.Add(this.but_messageinterval);
            this.Controls.Add(this.but_3dmap);
            this.Controls.Add(this.but_blupdate);
            this.Controls.Add(this.but_mavinspector);
            this.Controls.Add(this.but_proximity);
            this.Controls.Add(this.but_dem);
            this.Controls.Add(this.but_td);
            this.Controls.Add(this.but_logdlscp);
            this.Controls.Add(this.but_sortlogs);
            this.Controls.Add(this.but_GDAL);
            this.Controls.Add(this.myButton3);
            this.Controls.Add(this.but_followswarm);
            this.Controls.Add(this.but_gpsinj);
           
            this.Controls.Add(this.BUT_magfit2);
            this.Controls.Add(this.myButton2);
            this.Controls.Add(this.but_optflowcalib);
            this.Controls.Add(this.but_signkey);
            this.Controls.Add(this.myButton1);
            this.Controls.Add(this.but_agemapdata);
            this.Controls.Add(this.but_gstream);
            this.Controls.Add(this.myButton_vlc);
            this.Controls.Add(this.but_trimble);
            this.Controls.Add(this.BUT_QNH);
            this.Controls.Add(this.but_reboot);
            this.Controls.Add(this.BUT_fft);
            this.Controls.Add(this.but_injectgps);
            this.Controls.Add(this.but_sitl_comb);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "temp";
            this.Load += new System.EventHandler(this.temp_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Controls.MyButton BUT_geinjection;
        private Controls.MyButton BUT_clearcustommaps;
        private Controls.MyButton BUT_lang_edit;
        private Controls.MyButton BUT_georefimage;
        private Controls.MyButton BUT_follow_me;
        private Controls.MyButton BUT_paramgen;
        private Controls.MyButton BUT_outputMD;
        private Controls.MyButton but_osdvideo;
        private Controls.MyButton BUT_swarm;
        private Controls.MyButton BUT_outputnmea;
        private Controls.MyButton BUT_outputMavlink;
        private Controls.MyButton BUT_followleader;
        private Controls.MyButton BUT_sorttlogs;
        
        private Controls.MyButton BUT_movingbase;
        private Controls.MyButton but_getfw;
        private Controls.MyButton but_mavserialport;
        MissionPlanner.Controls.MyButton button3;
        private Controls.MyButton BUT_shptopoly;
        private Controls.MyButton but_gimbaltest;
        private Controls.MyButton but_maplogs;
        private Controls.MyButton butlogindex;
        private Controls.MyButton but_structtest;
        private Controls.MyButton but_armandtakeoff;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private Controls.MyButton but_sitl_comb;
        private Controls.MyButton but_injectgps;
        private Controls.MyButton BUT_fft;
        private Controls.MyButton but_reboot;
        private Controls.MyButton BUT_QNH;
        private Controls.MyButton but_trimble;
        private Controls.MyButton myButton_vlc;
        private Controls.MyButton but_gstream;
        private Controls.MyButton but_agemapdata;
        private Controls.MyButton myButton1;
        private Controls.MyButton but_signkey;
        private Controls.MyButton but_optflowcalib;
        private Controls.MyButton myButton2;
        private Controls.MyButton BUT_magfit2;
        private Controls.MyButton but_gpsinj;
        private Controls.MyButton but_followswarm;
        private Controls.MyButton myButton3;
        private Controls.MyButton but_GDAL;
        private Controls.MyButton but_sortlogs;
        private Controls.MyButton but_logdlscp;
        private Controls.MyButton but_td;
        private Controls.MyButton but_dem;
        private Controls.MyButton but_proximity;
        private Controls.MyButton but_dashware;
        private Controls.MyButton but_mavinspector;
        private Controls.MyButton but_blupdate;
        private Controls.MyButton but_3dmap;
        private Controls.MyButton but_anonlog;
        private Controls.MyButton but_messageinterval;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label12;
        private Controls.MyButton but_disablearmswitch;
        private Controls.MyButton but_hwids;
        private Controls.MyButton but_packetbytes;
        private Controls.MyButton but_acbarohight;
        private Controls.MyButton but_stayoutest;
        private Controls.MyButton but_driverclean;
    }
}