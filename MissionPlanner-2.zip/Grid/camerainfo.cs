﻿namespace MissionPlanner.Grid
{
    public struct camerainfo
    {
        public string name;
        public float focallen;
        public float sensorwidth;
        public float sensorheight;
        public float imagewidth;
        public float imageheight;
    }
}